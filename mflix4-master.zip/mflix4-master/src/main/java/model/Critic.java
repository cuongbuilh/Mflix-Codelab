package model;

import lombok.Data;

@Data
public class Critic {
    private int metter;
    private int numReviews;
    private double  rating;
}
