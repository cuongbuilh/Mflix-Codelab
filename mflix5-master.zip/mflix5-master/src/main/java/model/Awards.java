package model;

import lombok.Data;

@Data
public class Awards {
    private int nominations;
    private int wins;
    private String text;
}