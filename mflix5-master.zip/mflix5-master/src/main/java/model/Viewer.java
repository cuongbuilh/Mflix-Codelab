package model;

import lombok.Data;

@Data
public class Viewer {
    private int metter;
    private double rating;
    private int numReviews;
}

