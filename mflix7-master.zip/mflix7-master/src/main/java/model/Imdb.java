package model;

import lombok.Data;

@Data
public class Imdb {
    private int id;
    private double rating;
    private int votes;
}