# Mflix 6.0
##Data
Dữ liệu trên MongoAtlas
```
mongodb+srv://root:root@cluster0.lh5rj.mongodb.net
```

Dữ liệu trên Local
```
mongodb://localhost:27017
```
##Deploy

https://mflix2022.herokuapp.com/
